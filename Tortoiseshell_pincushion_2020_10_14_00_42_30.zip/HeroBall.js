class HeroBall {
  constructor(){
    this.x = 100;
    this.y = 300;
    this.r = 25;
    this.color1 = [120,90,220];
    this.color2 = [20,190,190];
    this.color3 = [70,20,220];
  }
  
  
  display(){
    fill(this.color1);
    ellipse(this.x, this.y, this.r * 2);
    fill(this.color2);
    ellipse(this.x, this.y, this.r );
    fill(this.color3);
    ellipse(this.x, this.y, this.r/2 );
  }
  
  burstForward(){
    if(this.x < 300){
       this.x+=60;
    }
   if(this.y - this.r > 30){
      this.y -=80;
   }
   
  }
  
  
  driftBack(){
    this.x -= 0.5;
    bgX+=0.15;
  }
  
  driftDown(){
    if(this.y + this.r < horizon){
      this.y += 1.5
    }
    
  }
  
  
  update(){
    this.driftBack();
    this.driftDown();
  }
}