let bg, hero, bgCounter = 0;
const horizon = 470;
let bgX = 0, bgY = 0;
let driftingForward = true;

const clouds = Array.from({length: 3}, (cloud, i) => {
    return new Cloud(i * (Math.random()* 100) + ((i+1) * 250), Math.random() * 150);
})

function preload(){
  bg = loadImage('ocean.png');
}

function setup() {
  createCanvas(500, 500);
  hero = new HeroBall();

}

function draw() {
  if(hero.x > 0){
    drawGame()
  } else {
    drawGameOver();
  }
}

function mousePressed(){
  driftingForward = false;
  setTimeout(resetDriftForward, 1500);
  hero.burstForward();
 bgCounter = 20;
 scrollBg();
  
}

function scrollBg(){
  bgX -=0.5;
  bgCounter -= 1;
  if(bgCounter > 0){
    setTimeout(scrollBg, 10);
  }
  
}

function drawGame(){
  if(!driftingForward){
    bgX -= 0.25;
  }
    
    image(bg, bgX, bgY, width, height,);
  
      clouds.forEach((cloud, i) => {
        if(cloud.x < -100){
            //soundCounter++;
            cloud.x += 900;
            cloud.puffs.forEach(puff => {
                puff.x += 900
            })
            //bumpball.sound = sounds[soundCounter%numSounds];

        }
        cloud.move();
        cloud.display();

    })
  

  
  hero.update();
  hero.display();
  
}

function drawGameOver(){
  background(0);
  fill(255);
  text('game over', 100, 200);
  text('click to restart', 100, 250);
}

function resetDriftForward(){
  driftingForward = true;
}

